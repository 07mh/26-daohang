//第三题
#include <iostream>
#include <string>
using namespace std;

class Car {
private:
    string color;
    int number;

public:
    Car(string c,int n){
        color=c;
        number=n;
        cout<<"构造函数调用："<<color<< endl;
    }

    ~Car() {
        cout<<"析构函数调用："<<color<<endl;
    }

    void display() {
        cout << "颜色：" << color << endl;
        cout << "车牌号：" << number << endl;
    }
};

int main() {
    Car car1("黑色", 12345);
    Car car2("白色", 67890);

    cout<<"车辆1信息："<<endl;
    car1.display();
    cout<<endl;
    cout<<"车辆2信息："<<endl;
    car2.display();
    cout<<endl;

    return 0;
}
