//第一题
#include <iostream>
using namespace std;

int main() {
    int a[10];
    cout <<"请输入10个整数："<< endl;
    
    for (int i=0;i<10;i++){
        cin >> a[i];
    }

    for (int i=0;i<9;i++){
        for (int j=0;j<9-i;j++){
            if (a[j]>a[j+1]){
                int t=a[j];
                a[j]=a[j+1];
                a[j+1]=t;
            }
        }
    }

    cout <<"升序输出:"<<endl;

    for (int i=0;i<10;i++){
        cout<<a[i]<<" ";
    }

    return 0;
}
