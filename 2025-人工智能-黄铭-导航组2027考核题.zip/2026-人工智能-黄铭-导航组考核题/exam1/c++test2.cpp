//第二题
#include <iostream>
using namespace std;

struct Student{
    char name[50];
    int id;
    float score;
};

void input(Student *p){
    cout<<"请输入姓名：";
    cin>>p->name;
    cout<<"请输入学号：";
    cin>>p->id;
    cout<<"请输入成绩：";
    cin>>p->score;
}

void display(Student *p){
    cout<<"姓名："<<p->name<<endl;
    cout<<"学号："<<p->id<<endl;
    cout<<"成绩："<<p->score<<endl;
}

int main() {
    Student *s=new Student;
    input(s);
    display(s);
    delete s;
    return 0;
}
